TEF 

    TEF is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    TEF is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with TEF.  If not, see <http://www.gnu.org/licenses/>.



Copyright (2011-2012) by Dirk STRATMANN, Jananan Sylvestre PATHMANATHAN, Jacques CHOMILIER, Paris VI University (UPMC)

This tool decomposes proteins 3D structures into sub-domain fragments, called "tightened end fragments" (TEF) or "closed loops".	

contact: dirk.stratmann__at__upmc.fr


REQUIREMENTS
------------

Necessary dependencies are:
- biopython (http://www.biopython.org)
Optional dependencies are:
- pymol
- naccess (http://www.bioinf.manchester.ac.uk/naccess/)
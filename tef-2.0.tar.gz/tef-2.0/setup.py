from distutils.core import setup, Extension
from distutils.command.install import install as DistutilsInstall
import os

class MyInstall(DistutilsInstall):
    def run(self):
        #do_pre_install_stuff()
        self.makeTefSearch()
        DistutilsInstall.run(self)
        #do_post_install_stuff()
    def makeTefSearch(self):
        os.chdir("tef")
        os.system("make")
        os.chdir("..")

setup(
    cmdclass={'install': MyInstall},
    name = "tef",
    version = "2.0",
    #packages = ["tef2"],
    #scripts = ["tef2.py", "tef2/tef_search"],
    scripts = ['tefs', 'tef/tef_search'],
    packages = ["tef"],
    #ext_modules=[Extension('tef_search', ['tef2/tef_search.cpp'])],
    description = "TEF",
    author = "Dirk Stratmann",
    author_email = "dirk.stratmann__at__upmc.fr",
    url = "http://www.impmc.upmc.fr",
    keywords = ["protein", "fragments", "closed loops", "tightened end fragments"],
    classifiers = [
        "Programming Language :: Python",
        "License :: OSI Approved :: GNU General Public License (GPL)",
        "Operating System :: Unix",
        'Topic :: Scientific/Engineering :: Bio-Informatics',
        'Topic :: Software Development :: Libraries :: Python Modules',
        ],
    long_description = """\
TEF 2.0 

Written (2011-2012) by Dirk STRATMANN, Jananan Sylvestre PATHMANATHAN, Jacques CHOMILIER, Paris VI University (UPMC)

This tool decomposes proteins 3D structures into sub-domain fragments, called "tightened end fragments" (TEF) or "closed loops".	

REQUIREMENTS
------------

Dependencies are:
- naccess (http://www.bioinf.manchester.ac.uk/naccess/)
- biopython (http://www.biopython.org)
- pymol
"""
)

